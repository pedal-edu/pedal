# Run the environment variable initializer to get access to its variables
source ./vpl_environment.sh
echo "#!/bin/bash" > vpl_execution
echo "python3.6 -m pedal grade on_run.py $VPL_SUBFILE0 --environment vpl">> vpl_execution
chmod +x vpl_execution