from pedal import *

# VPL let's you specify a maximum score for an assignment
from pedal.environments.vpl import set_maximum_score
set_maximum_score(100)

#########################################################
# These are special extensions from my curriculum, not part of pedal itself
# you may or may not want them.
from curriculum_sneks import (ensure_cisc108_tests,
                              prevent_printing_functions,
                              ensure_functions_return)
# Make sure they have cisc108 module and 3 assert_equal tests
# And also that all of their unit tests are passing
ensure_cisc108_tests(3) #, module_name='cisc106'
# Don't allow print calls inside function definitions
prevent_printing_functions()
# Make sure they have return statements inside function definitions
ensure_functions_return()

#########################################################
# These are all native Pedal assertions

# Make sure all functions have a docstring
ensure_documented_functions()
# Must have a for loop
ensure_ast("For")
# They must call the contains function
ensure_function_call("contains")

DISALLOW_MESSAGE = "Uses disallowed tools. Please watch the video. Testing will halt now."
# No while loops
prevent_ast("While")
# Prevent these functions and methods
prevent_function_call("index", message=DISALLOW_MESSAGE)
prevent_function_call("range", message=DISALLOW_MESSAGE)
prevent_function_call("sum", message=DISALLOW_MESSAGE)
prevent_function_call("append", message=DISALLOW_MESSAGE)
prevent_function_call("extend", message=DISALLOW_MESSAGE)
# They can't use this module
prevent_import("operator", message=DISALLOW_MESSAGE)
# Prevent this operation
prevent_operation("in", message=DISALLOW_MESSAGE)
prevent_operation("not in", message=DISALLOW_MESSAGE)

# They must have 90% code coverage
ensure_coverage(.9)

# Must define evens2 with one parameter
ensure_function('contains', arity=2)
# Unit test the function
# This has a lot of bells and whistles
unit_test('contains', 
          ([1, []], False),
          ([3,[3]], True),
          ([3,[1, 5, 2, 4, 3]], True),
          ((1,[1, 5, 4, 5, 3]), True),
          (('a','bat'), True),
          ((1,[2]), False),
          ((0,[5]), False),
          message="Failing instructor tests",
          score="+100%", partial_credit=True
)

# Or you can assert individually
# assert_equal(call('contains', 1,[]), False)
# assert_equal(call('contains', 3,[3]), True)
# assert_equal(call('contains', 3,[1, 5, 2, 4, 3]), True)
# assert_equal(call('contains', 1,[1, 5, 4, 5, 3]), True)
# assert_equal(call('contains', 'a','bat'), True)
# assert_equal(call('contains', 1,[2]), False)
# assert_equal(call('contains', 0,[5]), False)
